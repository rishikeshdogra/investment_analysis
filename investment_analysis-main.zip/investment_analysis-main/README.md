# Investment Analysis - Spark Funds

Spark Funds, an asset management company wants to make investments in a few companies. The CEO of Spark Funds wants to understand the global trends in investments so that he can take the investment decisions effectively.
